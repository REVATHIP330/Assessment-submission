module.exports = {
  john: [
    {
      date: "1/1/2022",
      amount: 100,
    },
    {
      date: "2/1/2022",
      amount: 10,
    },
    {
      date: "3/1/2022",
      amount: 200,
    },
    {
      date: "1/1/2022",
      amount: 650,
    },
    {
      date: "1/1/2022",
      amount: 110,
    },
    {
      date: "3/1/2022",
      amount: 500,
    },
    {
      date: "2/1/2022",
      amount: 170,
    },
    {
      date: "3/1/2022",
      amount: 120,
    },
  ],
  paul: [
    {
      date: "1/1/2022",
      amount: 100,
    },
    {
      date: "2/28/2022",
      amount: 140,
    },
    {
      date: "3/15/2022",
      amount: 1300,
    },
    {
      date: "2/11/2022",
      amount: 256,
    },
    {
      date: "3/24/2022",
      amount: 35,
    },
    {
      date: "2/2/2022",
      amount: 115,
    },
  ],
  steve: [
    {
      date: "2/1/2022",
      amount: 2354,
    },
    {
      date: "1/26/2022",
      amount: 120,
    },
    {
      date: "3/4/2022",
      amount: 114,
    },
    {
      date: "3/24/2022",
      amount: 345,
    },
    {
      date: "1/2/2022",
      amount: 2389,
    },
    {
      date: "1/12/2022",
      amount: 1456,
    },
    {
      date: "2/12/2022",
      amount: 38,
    },
  ],
  mary: [],
};
